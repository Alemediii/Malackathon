#.libPaths()
#library(readxl)

library(readxl)
datos <- read_excel("C:/Users/Alejandro/Desktop/PROJECTS/MALACKANALISIS/SaludMental.xls")
head(datos)